﻿using System;
using Enums;
using Enum_library;


namespace HouseofCoffee
{
    class Program
    {
        static void Main(string[] args)
        {
            Revandsales revandsales = new Revandsales();
            //Payroll payroll = new Payroll();

            Console.WriteLine("Welcome to The House of Coffee.");
            Console.WriteLine("Enter the number corresponding to what you want to do");
            Console.WriteLine("1. Calculate revenue and sales.");
            Console.WriteLine("2. Calculate payrole.");
            Console.WriteLine("3. Exit");

            try
            {
                char userChoice = Convert.ToChar(Console.ReadLine());

                switch (userChoice)
                {
                    case '1':

                        revandsales.Sold();
                        Console.ReadLine();
                        break;
                }

                switch (userChoice)
                {
                    case '2':

                        Payroll.payroll();
                        Console.ReadLine();
                        break;
                }

                switch (userChoice)
                {
                    case '3':
                        Console.WriteLine("Thanks for stopping by!");
                        return;
                }
            
            }
            catch (FormatException)
            {
                Console.WriteLine(" Invalid entry");

            }
            catch (Exception)
            {
                Console.WriteLine(" Invalid entry");
            }
            Console.Read();
        }
    }
}