﻿

namespace Enums
{

    public enum Menu: long
    {
        SmallCoffee,
        MediumCoffee,
        LargeCoffee,
        EggSandwich,
        ChickenBiscuit
    }

    enum Employees: long
    {
        Employee1,
        Employee2,
        Employee3,
        Employee4,
        Employee5
    }
}