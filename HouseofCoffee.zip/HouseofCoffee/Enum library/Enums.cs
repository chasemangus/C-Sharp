﻿using System;
using Enums;
namespace Structures
{
    public struct Coffee
    {
        public string Size;
        public double Price;
        public double Cost;
    }

    public struct EggSandwich
    {
        public double Price;
        public double Cost;
    }

    public struct ChickenBiscuit
    {
        public double Price;
        public double Cost;
    }
}