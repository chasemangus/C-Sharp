﻿using System;
using Enums;
using Structures;

namespace HouseofCoffee
{
   
    public class Revandsales
    {
        double smallCoffeePrice = 1.00;
        double mediumCoffeePrice = 3.00;
        double largeCoffeePrice = 5.00;
        double eggSandwichPrice = 5.50;
        double chickenBiscuitsPrice = 7.50;

        double smallCoffeeCosts = 0.1;
        double mediumCoffeeCosts = 0.15;
        double largeCoffeeCosts = 0.2;
        double eggSandwichCosts = 0.95;
        double chickenBiscuitsCosts = 1.20;


        public void Sold()
        {
            Console.WriteLine("Enter number of small coffees sold");
            double SmallCoffeeSold = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter number of meduim coffees sold");
            double MediumCoffeeSold = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter number of large coffees sold");
            double largeCoffeeSold = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter number of egg sandwiches sold");
            double EggSandwichSold = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter number of chicken biscuits sold");
            double ChickenBiscuitSold = Convert.ToDouble(Console.ReadLine());



            double SmSold = (smallCoffeePrice * SmallCoffeeSold);
            double MdSold = (mediumCoffeePrice * MediumCoffeeSold);
            double LgSold = (largeCoffeePrice * largeCoffeeSold);
            double EggsandSold = (eggSandwichPrice * EggSandwichSold);
            double ChickenSold = (chickenBiscuitsPrice * ChickenBiscuitSold);

            double SmCost = (smallCoffeeCosts * SmallCoffeeSold);
            double MdCost = (mediumCoffeeCosts * MediumCoffeeSold);
            double LgCost = (largeCoffeeCosts * largeCoffeeSold);
            double EggsandCost = (eggSandwichCosts * EggSandwichSold);
            double ChickenCost = (chickenBiscuitsCosts * ChickenBiscuitSold);

            double SmProfit = (SmSold - SmCost);
            double MdProfit = (MdSold - MdCost);
            double LgProfit = (LgSold - LgCost);
            double EggsandProfit = (EggsandSold - EggsandCost);
            double ChickenProfit = (ChickenSold - ChickenCost);

            double TotalSold = (SmSold + MdSold + LgSold + EggsandSold + ChickenSold );
            double TotalCost = (SmCost + MdCost + LgCost + EggsandCost + ChickenCost);
            double TotalProfit = (SmProfit + MdProfit + LgProfit + EggsandProfit + ChickenProfit);

            Console.WriteLine($"  Sold {TotalSold:c} , Cost {TotalCost:c}, Profit {TotalProfit:c}");
        }

    }
   
}
