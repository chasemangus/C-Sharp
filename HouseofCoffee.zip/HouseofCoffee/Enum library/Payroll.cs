﻿using System;


namespace Enum_library
{
    public class Payroll
    {
        
        public static void payroll()
        {
            double regPay = 0.00;
            double overtimePay = 0.00;
            double hoursworked = 0;
            double regularhr = 0;
            double overtimehr = 0;
            double totalpay = 0;

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(" Enter number of hours worked.");
                hoursworked = Convert.ToDouble(Console.ReadLine());
                if (hoursworked > 40)
                {
                    regularhr += 40;

                    overtimehr += (hoursworked - 40) * 1.5;

                }
                else
                {
                    regularhr += hoursworked;
                }

            }

            regPay = 12.5 * regularhr;
            overtimePay = 12.5 * overtimehr;
            totalpay = regPay + overtimePay;

            Console.WriteLine($" Total Regular pay {regPay:c}");
            Console.WriteLine($" Total Overtime pay {overtimePay:c}");
            Console.WriteLine($" Total pay {totalpay:c}");
        }   

    }
}
