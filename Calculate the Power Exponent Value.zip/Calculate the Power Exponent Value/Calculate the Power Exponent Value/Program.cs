﻿/*
 *  C# Program to Calculate the power exponent value
 */

using System;
class Program
{
    static void Main()
    {
        Int64 baseNumber, expNumber;

        /* "Base Number" input */
        Console.WriteLine("Enter the Base Number : ");

        /* Assigns "Base Number" imput, and converts string to int. */
        baseNumber = Int64.Parse(Console.ReadLine());

        /* "Exponent Number" input */
        Console.WriteLine("Enter the Exponent : ");

        /* Assigns " Exponent Number " imput, and converts string to int. */
        expNumber = Int64.Parse(Console.ReadLine());

        /* Sets power */
        double value = Math.Pow(baseNumber, expNumber);

        /* Displays output */
        Console.WriteLine("Result : {0}", value);
        Console.ReadLine();
    }
}