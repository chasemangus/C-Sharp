using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathApp
{
    class Program
    {

        static void Main()
        {

            Console.WriteLine("Enter the operation + (addition), - (subtraction), * (multiplication), / (division)");
            Console.WriteLine("press any key to exit");
            string operation = Console.ReadLine();

            switch (operation)
            {
                case "+":
                    addition();
                    break;

                case "-":
                    subtraction();
                    break;

                case "*":
                    multiplication();
                    break;

                case "/":
                    division();
                    break;

                default:
                    Console.WriteLine("thanks for stopping by!");
                    Console.ReadLine();
                    Environment.Exit(0);
                    break;
            }
        }

        static void addition()
        {
            Console.WriteLine("Type your first number : ");
            double firstNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Type your second number : ");
            double secondNumber = Convert.ToDouble(Console.ReadLine());
            double result = firstNumber + secondNumber;
            Console.WriteLine($"{firstNumber} + {secondNumber} = {result}");
            Console.ReadLine();
        }

        static void subtraction()
        {
            Console.WriteLine("Type your first number : ");
            double firstNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Type your second number : ");
            double secondNumber = Convert.ToDouble(Console.ReadLine());
            double result = firstNumber - secondNumber;
            Console.WriteLine($"{firstNumber} - {secondNumber} = {result}");
            Console.ReadLine();
        }

        static void multiplication()
        {
            Console.WriteLine("Type your first number : ");
            double firstNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Type your second number : ");
            double secondNumber = Convert.ToDouble(Console.ReadLine());
            double result = firstNumber * secondNumber;
            Console.WriteLine($"{firstNumber} * {secondNumber} = {result}");
            Console.ReadLine();
        }

        static void division()

        {
            Console.WriteLine("Type your first number : ");
            double firstNumber = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Type your second number : ");
            double secondNumber = Convert.ToDouble(Console.ReadLine());
            double result = 0;
            Console.ReadLine();

            if (secondNumber != 0)
            { result = firstNumber / secondNumber; }
            else
            {
                Console.WriteLine("Second Number can not be zero for division operation, enter new number:");

                secondNumber = Convert.ToDouble(Console.ReadLine());
                result = firstNumber / secondNumber;
            }
            Console.WriteLine($"{firstNumber} / {secondNumber} = {result}");
            Console.ReadLine();
        }
    }
}
