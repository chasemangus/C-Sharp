using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISTA_220_Lab_3C_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculate();
        }
        static void Calculate()
        {
            double amount = 6000;
            double interest = 0.02;
            int years = 4;
            double balance = amount * interest;

            for (int i = 0; i <= years; i++)
            {
                amount += amount * (interest);
                Console.WriteLine($"Year {i + 1} Tuition is: {amount:c}");
            }

            Console.ReadLine();
        }
    }
}