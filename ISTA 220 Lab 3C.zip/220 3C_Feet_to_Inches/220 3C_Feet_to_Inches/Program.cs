using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISTA_220_Lab_3C
{
    class Program
    {
        public static void Main(string[] args)
        {
            Calculate();
        }
        static void Calculate()
        {

            Console.WriteLine("Imput Number of feet");
            double Feet = Convert.ToDouble(Console.ReadLine());

            //converting into inches
            double Inches = (Feet * 12);

            Console.WriteLine($"Converts to { Inches} Inches.");
            Console.ReadLine();

        }
    }
}