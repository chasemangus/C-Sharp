using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Monthly_Sales_Tax
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Imput Total Sales");
            double ts = Convert.ToDouble(Console.ReadLine());
            double st = .04;
            double ct = .02;
            double State = ts * st;
            double county = ts * ct;
            double total = State + county;

            Console.WriteLine($" The amount of county sales tax is {county:c},");
            Console.WriteLine($" The amount of state sales tax is {State:c},");
            Console.WriteLine($" The Total Sales tax is {total:c},");
            Console.ReadLine();
        }
    }
}
