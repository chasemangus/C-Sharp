﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            triangle();
            triangleAdvanced();
        }

        static void triangle()
        {
            int i, j;

            Console.WriteLine("Enter number of rows for the triangle");
            int number = Convert.ToInt32(Console.ReadLine());

            for (i = 0; i < number; i++)
            {
                int numberOfSpaces = i;
                int numberOfNumbers = (number * 2 - 1) - (2 * numberOfSpaces);

                for (j = 1; j <= numberOfNumbers; j++)
                {
                    Console.Write(number);
                }

                Console.WriteLine("");
            }
            Console.Read();
        }
        
        static void triangleAdvanced()
        {

            int number;
            int i, j, k;

            Console.WriteLine("Enter number of rows");

            if (int.TryParse(Console.ReadLine(), out number))
            {
                for (i = 0; i < number; i++)
                {
                    int numberOfSpaces = i;
                    int numberOfNumbers = (number * 2 - 1) - (2 * numberOfSpaces);

                    for (j = 1; j <= numberOfSpaces; j++)
                    {
                        Console.Write(" ");
                    }

                    for (k = 1; k <= numberOfNumbers; k++)
                    {
                        Console.Write(number);
                    }

                    Console.WriteLine("");
                }
            }
            else
            {
                Console.WriteLine("No number entered.");
            }

            Console.Read();
        }

    }
}
