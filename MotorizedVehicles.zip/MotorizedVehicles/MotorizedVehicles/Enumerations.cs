﻿
namespace Enumerations
{
        public enum EngineType: short
        {
            V4,
            V6,
            V8
        }
}
